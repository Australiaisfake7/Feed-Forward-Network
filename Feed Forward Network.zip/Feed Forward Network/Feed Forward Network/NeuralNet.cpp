#include <vector>
#include <string>
#include <numeric>
#include <iostream>
#include <fstream>
#include "NeuralNet.h"

const std::vector<unsigned int> NeuralNetwork::layerSizes = { 28 * 28, 32, 16, 10 };
unsigned int NeuralNetwork::numLayers = layerSizes.size();
std::vector<std::vector<float>> NeuralNetwork::nodes;
std::vector<std::vector<float>> NeuralNetwork::rawNodes;
std::vector<std::vector<float>> NeuralNetwork::deltas;


std::vector<unsigned int> NeuralNetwork::weightCounts = std::vector<unsigned int>(numLayers - 1);
std::vector<std::vector<float>> NeuralNetwork::weights;
std::vector<std::vector<float>> NeuralNetwork::weightDerivatives;
std::vector<std::vector<float>> NeuralNetwork::biasDerivatives;

std::vector<unsigned int> NeuralNetwork::biasCounts = std::vector<unsigned int>(numLayers - 1);
std::vector<std::vector<float>> NeuralNetwork::biases;

std::vector<std::vector<float>> NeuralNetwork::weightShape;
std::vector<std::vector<float>> NeuralNetwork::biasShape;

void NeuralNetwork::gen_jagged_array(std::vector<std::vector<float>>& floats, const std::vector<unsigned int> counts, unsigned int length)
{
	floats.resize(length);
	for (size_t i = 0; i < length; i++)
	{
		floats[i].resize(counts[i]);
	}
}

void NeuralNetwork::gen_weight_counts(std::vector<std::vector<float>>& nodes, std::vector<unsigned int>& weights, unsigned int length)	
{
	for (size_t i = 0; i < length; i++)
	{
		weights[i] = nodes[i].size() * nodes[i + 1].size();
	}
}

void NeuralNetwork::gen_bias_counts(std::vector<std::vector<float>>& nodes, std::vector<unsigned int>& biases, unsigned int length)
{
	for (size_t i = 1; i <= length; i++)
	{
		biases[i - 1] = nodes[i].size();
	}
}

void NeuralNetwork::randomize_array(std::vector<std::vector<float>>& floats)
{
	for (size_t i = 0; i < floats.size(); i++)
	{
		for (size_t j = 0; j < floats[i].size(); j++)
		{
			float limit = sqrt(6.0f / (layerSizes[i] + layerSizes[i + 1]));
			floats[i][j] = (((float)rand() / RAND_MAX) * 2.0f - 1.0f) * limit;
		}
	}
}

float NeuralNetwork::sigmoid(float x)
{
	return 1 / (1 + exp(-x));
}

void NeuralNetwork::gen_network()
{
	gen_jagged_array(nodes, layerSizes, numLayers);
	gen_jagged_array(rawNodes, layerSizes, numLayers);
	gen_jagged_array(deltas, layerSizes, numLayers);

	gen_weight_counts(nodes, weightCounts, numLayers - 1);
	gen_jagged_array(weights, weightCounts, numLayers - 1);

	// Store the array with empty values for initializing other arrays
	weightShape = weights;

	randomize_array(weights);
	gen_jagged_array(weightDerivatives, weightCounts, numLayers - 1);

	gen_bias_counts(nodes, biasCounts, numLayers - 1);
	gen_jagged_array(biases, biasCounts, numLayers - 1);

	// Store the array with empty values for initializing other arrays
	biasShape = biases;

	gen_jagged_array(biasDerivatives, biasCounts, numLayers - 1);
}

unsigned int NeuralNetwork::evaluate_input(std::vector<unsigned char> inputs)
{
	//Convert unsigned char to 0-1
	for (size_t i = 0; i < nodes[0].size(); i++)
	{
		nodes[0][i] = inputs[i] / 255.0f;
	}

	//Propogate values forward
	for (size_t i = 1; i < nodes.size(); i++)
	{
		for (size_t j = 0; j < nodes[i].size(); j++)
		{
			float sum = 0.0f;
			for (size_t k = 0; k < nodes[i-1].size(); k++)
			{
				sum += nodes[i - 1][k] * weights[i - 1][k * nodes[i].size() + j];
			}
			rawNodes[i][j] = sum + biases[i - 1][j];
			nodes[i][j] = sigmoid(sum + biases[i - 1][j]);
		}
	}

	//Find strongest output
	unsigned int output = 0;
	float activation = 0.0f;
	for (size_t i = 0; i < nodes[nodes.size() - 1].size(); i++)
	{
		float nodeValue = nodes[nodes.size() - 1][i];
		if (nodeValue > activation)
		{
			activation = nodeValue;
			output = i;
		}
	}
	return output;
}

void NeuralNetwork::calculate_derivatives(std::vector<float> targets, std::vector<std::vector<float>>& w, std::vector<std::vector<float>>& b)
{
	// --- Calculate deltas ---

	//Iterate over all layerSizes
	for (int i = numLayers - 1; i > 0; i--)
	{
		//Iterate over nodes in layer
		for (size_t j = 0; j < layerSizes[i]; j++)
		{
			//Check if on last layer
			if (i < numLayers - 1)
			{
				float sum = 0.0f;
				//Iterate over nodes in next layer
				for (size_t k = 0; k < layerSizes[i + 1]; k++)
				{
					//Sum up next delta multiplied by connection to that delta
					sum += deltas[i + 1][k] * weights[i][j * nodes[i + 1].size() + k];
				}
				float z = rawNodes[i][j];
				deltas[i][j] = sum * sigmoid(z) * (1 - sigmoid(z));
			}
			else
			{
				//Calculate change in cost with change in output node
				float a = nodes[i][j];
				deltas[i][j] = (a - targets[j]) * a * (1 - a);
			}
		}
	}

	// --- Calculate partial derivatives ---
	for (size_t i = 0; i < numLayers - 1; i++)
	{
		for (size_t j = 0; j < nodes[i].size(); j++)
		{
			for (size_t k = 0; k < nodes[i + 1].size(); k++)
			{
				//Iterate over every connection j to k
				//Weight gradient is equal to activation j * delta k

				weightDerivatives[i][j * nodes[i + 1].size() + k] = nodes[i][j] * deltas[i + 1][k];
			}
		}
	}
	for (size_t i = 1; i < numLayers; i++)
	{
		for (size_t j = 0; j < nodes[i].size(); j++)
		{
			//Bias gradient is equal to delta
			biasDerivatives[i-1][j] = deltas[i][j];
		}
	}

	// --- Output Gradients ---

	b = biasDerivatives;
	w = weightDerivatives;
}

void NeuralNetwork::update_parameters(std::vector<std::vector<float>>& w, std::vector<std::vector<float>>& b, float learnRate, int batchSize)
{
	// --- Adjust weights and biases ---
	for (size_t i = 0; i < numLayers - 1; i++)
	{
		for (size_t j = 0; j < nodes[i].size(); j++)
		{
			for (size_t k = 0; k < nodes[i + 1].size(); k++)
			{
				int index = j * nodes[i + 1].size() + k;
				weights[i][index] -= w[i][index] * learnRate / batchSize;
			}
		}
	}

	for (size_t i = 0; i < numLayers - 1; i++)
	{
		for (size_t j = 0; j < nodes[i + 1].size(); j++)
		{
			biases[i][j] -= b[i][j] * learnRate / batchSize;
		}
	}
}

void NeuralNetwork::debug_layer_stats()
{
	std::cout << "---- Layer diagnostics ----" << std::endl;
	for (size_t i = 0; i < nodes.size(); i++)
	{
		float mean = 0.0f;
		float minVal = FLT_MAX;
		float maxVal = -FLT_MAX;

		for (float v : nodes[i])
		{
			mean += v;
			minVal = std::min(minVal, v);
			maxVal = std::max(maxVal, v);
		}

		mean /= nodes[i].size();
		std::cout << "Layer " << i
			<< " | mean: " << mean
			<< " | min: " << minVal
			<< " | max: " << maxVal << std::endl;
	}

	std::cout << "----------------------------" << std::endl;
}

void NeuralNetwork::write_parameters(const char* fileName)
{
	std::fstream myFile(fileName, std::ios::out);

	// --- Write Parameters To File ---
	if (myFile.is_open())
	{
		// Write layer sizes
		for (size_t i = 0; i < layerSizes.size(); i++)
		{
			myFile << layerSizes[i] << "\n";
		}

		myFile << "weights" << "\n";

		// Write weights and indices
		for (size_t i = 0; i < weights.size(); i++)
		{
			for (size_t j = 0; j < weights[i].size(); j++)
			{
				myFile << i << " " << j << " " << weights[i][j] << "\n";
			}
		}

		myFile << "biases" << "\n";

		// Write biases and indices
		for (size_t i = 0; i < biases.size(); i++)
		{
			for (size_t j = 0; j < biases[i].size(); j++)
			{
				myFile << i << " " << j << " " << biases[i][j] << "\n";
			}
		}

		myFile.close();
		std::cout << "Parameters Written To File" << std::endl;
	}

}

void NeuralNetwork::read_parameters(const char* fileName)
{
	std::fstream myFile(fileName, std::ios::in);

	if (myFile.is_open())
	{
		std::string line;
		size_t section = 0;

		std::vector<unsigned int> loadedLayerSizes;

		// --- Read Parameters From File ---
		while (std::getline(myFile, line))
		{
			// Check if reading layer sizes
			if (section == 0)
			{

				// Check for indication to start reading weights
				if (line == "weights")
				{
					section++;

					// Check if layer sizes are the same
					if (loadedLayerSizes != layerSizes)
						return;
				}
				else
				{
					// Add layer size to vector
					loadedLayerSizes.push_back(std::stoi(line));
				}
			}

			// --- Update Weights ---
			else if (section == 1)
			{

				if (line == "biases")
				{
					section++;
				}
				else
				{
					std::vector<std::string> splitStrings(1);
					size_t stringSegment = 0;

					// Iterate over characters in line
					for (int i = 0; i < line.size(); i++)
					{
						// If character is space start writing to next member
						if (line[i] == ' ')
						{
							stringSegment++;
							splitStrings.push_back("");
						}

						// Write to member one character at a time
						else
						{
							splitStrings[stringSegment] += line[i];
						}
					}

					// Set weight based on values
					weights[std::stoi(splitStrings[0])][std::stoi(splitStrings[1])] = std::stof(splitStrings[2]);
				}
			}

			/// --- Update Biases ---
			else if (section == 2)
			{
				std::vector<std::string> splitStrings(1);
				size_t stringSegment = 0;

				// Iterate over characters in line
				for (int i = 0; i < line.size(); i++)
				{
					// If character is space start writing to next member
					if (line[i] == ' ')
					{
						stringSegment++;
						splitStrings.push_back("");
					}

					// Write to member one character at a time
					else
					{
						splitStrings[stringSegment] += line[i];
					}
				}

				// Set bias based on values
				biases[std::stoi(splitStrings[0])][std::stoi(splitStrings[1])] = std::stof(splitStrings[2]);
			}
		}
	}
}

float NeuralNetwork::get_accuracy(const std::vector<std::vector<unsigned char>>& images, const std::vector<unsigned char>& targets)
{
	unsigned int correct = 0;

	for (size_t i = 0; i < images.size(); i++)
	{
		unsigned int answer = evaluate_input(images[i]);

		if (answer == targets[i])
			correct++;
	}

	return float(correct) / images.size();
}
#pragma once

#include <vector>

class NeuralNetwork

{
private:
	static const std::vector<unsigned int> layerSizes;
	static unsigned int numLayers;
	static std::vector<std::vector<float>> nodes;
	static std::vector<std::vector<float>> rawNodes;
	static std::vector<std::vector<float>> weightDerivatives;
	static std::vector<std::vector<float>> biasDerivatives;
	static std::vector<std::vector<float>> deltas;

	static std::vector<unsigned int> weightCounts;
	static std::vector<std::vector<float>> weights;

	static std::vector<unsigned int> biasCounts;
	static std::vector<std::vector<float>> biases;

	static void gen_jagged_array(std::vector<std::vector<float>>& floats, const std::vector<unsigned int> counts, unsigned int length);

	static void gen_weight_counts(std::vector<std::vector<float>>& nodes, std::vector<unsigned int>& connections, unsigned int length);

	static void gen_bias_counts(std::vector<std::vector<float>>& nodes, std::vector<unsigned int>& biases, unsigned int length);

	static void randomize_array(std::vector<std::vector<float>>& floats);

	static float sigmoid(float x);

public:
	static std::vector<std::vector<float>> weightShape;
	static std::vector<std::vector<float>> biasShape;

	static void gen_network();

	static unsigned int evaluate_input(std::vector<unsigned char> gridData);

	static void calculate_derivatives(std::vector<float> targets, std::vector<std::vector<float>>& w, std::vector<std::vector<float>>& b);

	static void update_parameters(std::vector<std::vector<float>>& w, std::vector<std::vector<float>>& b, float learnRate, int batchSize);

	static void debug_layer_stats();

	static void write_parameters(const char* fileName);

	static void read_parameters(const char* fileName);

	static float get_accuracy(const std::vector<std::vector<unsigned char>>& images, const std::vector<unsigned char>& targets);
};
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <fstream>
#include <unordered_map>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "imgui/imgui.h"
#include "imgui/backends/imgui_impl_glfw.h"
#include "imgui/backends/imgui_impl_opengl3.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "NeuralNet.h"
#include "GLHelper.h"

float lastTime;
float deltaTime;
int xPos;
int yPos;
bool showUI = true;

int screenWidth = 800;
int screenHeight = 600;

// --- Project specific global variables ---
constexpr int gridSize = 28;
float screenSplit = 0.7f;
std::vector<unsigned char> gridData = std::vector<unsigned char>(gridSize * gridSize); 
unsigned int gridTexture;

int atlasWidth;
int atlasHeight;
std::unordered_map<unsigned int, GLHelper::Character> characters;

bool mouseClicked;
bool shiftPressed;

int clickedGridSquare;

int get_grid_square(int xPos, int yPos,int width, int height, int gridSize, float padding)
{
    yPos = height - yPos;
    int gridPixelSize = static_cast<int>(floor(std::min(width, height) * (1-padding)));
    int xPadding = (width - gridPixelSize) / 2;
    int yPadding = (height - gridPixelSize) / 2;
    if (xPos < xPadding || xPos >= gridPixelSize + xPadding || yPos < yPadding || yPos >= gridPixelSize + yPadding)
        return -1;
    float gridSquareSize = static_cast<float>(gridPixelSize) / gridSize;
    int xCenter = (xPos - xPadding) / gridSquareSize;
    int yCenter = (yPos - yPadding) / gridSquareSize;
    return xCenter + yCenter * gridSize;
}

bool square_in_grid(int index)
{
    return index >= 0 && index < gridSize * gridSize;
}

unsigned int gen_character_texture(const char* name, int* width, int* height, int* channels)
{
    unsigned char* pixels = stbi_load(name, width, height, channels, 0);
    unsigned int tex;
    glGenTextures(1, &tex);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, *width, *height, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels);
    stbi_image_free(pixels);
    return tex;
}

unsigned int gen_grid_texture(int size)
{
    unsigned int tex;
    glGenTextures(1, &tex);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RED, size, size, 0, GL_RED, GL_UNSIGNED_BYTE, gridData.data());

    //Point Filtering for grid look
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);

    float borderColor[] = { 0.1f,0.1f,0.1f,1.0f };
    glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, borderColor);

    return tex;
}

void gen_character_buffers(std::string text, std::vector<float>& vertices, std::vector<unsigned int>& indices, unsigned int* VAO, unsigned int* VBO, unsigned int* EBO)
{
    vertices.resize(text.length() * 16);
    indices.resize(text.length() * 6);
    GLHelper::gen_bitmap_verts(text, characters, vertices, indices, 0, screenHeight / 2, static_cast<int>(screenWidth * (1 - screenSplit)), screenHeight, atlasWidth, atlasHeight);

    GLHelper::gen_render_buffers(VAO, VBO, EBO, vertices.data(), vertices.size() * sizeof(float), indices.data(), indices.size() * sizeof(unsigned int));

    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);
}

void cursor_position_callback(GLFWwindow* window, double xpos, double ypos)
{
    xPos = xpos;
    yPos = ypos;
}

void set_grid_square(int i, unsigned char color)
{
    gridData[i] = color;
}

void set_grid_squares(int i, unsigned char color, float radius)
{
    int r = static_cast<int>(ceil(radius));

    int xCenter = i % gridSize;
    int yCenter = (i - xCenter) / gridSize;

    for (int y = -r; y <= r; y++)
    {
        for (int x = -r; x <= r; x++)
        {
            float dist = sqrt(pow(x, 2) + pow(y, 2));
            if (dist <= radius)
            {
                int offsetGridPos = i + y * gridSize + x;

                int newX = xCenter + x;
                int newY = yCenter + y;

                if (square_in_grid(offsetGridPos) && newX >= 0 && newX < gridSize && newY >= 0 && newY < gridSize)
                {
                    set_grid_square(offsetGridPos, std::min(gridData[offsetGridPos] + color * exp(-dist * dist) / 2, 255.0f));
                }
            }
        }
    }
}

void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
    if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
    {
        mouseClicked = true;
    }
    if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_RELEASE)
    {
        mouseClicked = false;
    }
}

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{ 
    glViewport(0, 0, width, height);
    screenWidth = width;
    screenHeight = height;
}

void process_input(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
    if (glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS)
        shiftPressed = true;
    if (glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_RELEASE)
        shiftPressed = false;
}

int reverse_int(int i) {
    unsigned char c1 = i & 255;
    unsigned char c2 = (i >> 8) & 255;
    unsigned char c3 = (i >> 16) & 255;
    unsigned char c4 = (i >> 24) & 255;
    return ((int)c1 << 24) + ((int)c2 << 16) + ((int)c3 << 8) + c4;
}

void clear_grid()
{
    for (size_t i = 0; i < gridData.size(); i++)
    {
        set_grid_square(i, 0);
    }
    glDeleteTextures(1, &gridTexture);
    gridTexture = gen_grid_texture(gridSize);
}

// Reads the MNIST image file (e.g. "train-images-idx3-ubyte" or "t10k-images-idx3-ubyte")
std::vector<std::vector<unsigned char>> read_mnist_images(const std::string& filename, unsigned int* numImages) {
    std::ifstream file(filename, std::ios::binary);
    if (!file.is_open())
        throw std::runtime_error("Cannot open file: " + filename);

    int magic_number = 0, num_images = 0, rows = 0, cols = 0;
    file.read((char*)&magic_number, 4);
    file.read((char*)&num_images, 4);
    file.read((char*)&rows, 4);
    file.read((char*)&cols, 4);

    magic_number = reverse_int(magic_number);
    num_images = reverse_int(num_images);
    rows = reverse_int(rows);
    cols = reverse_int(cols);

    if (magic_number != 2051)
        throw std::runtime_error("Invalid MNIST image file!");

    std::vector<std::vector<unsigned char>> images(num_images, std::vector<unsigned char>(rows * cols));
    for (int i = 0; i < num_images; ++i)
        file.read((char*)images[i].data(), rows * cols);

    *numImages = num_images;
    return images;
}

// Reads the MNIST label file (e.g. "train-labels-idx1-ubyte" or "t10k-labels-idx1-ubyte")
std::vector<unsigned char> read_mnist_labels(const std::string& filename) {
    std::ifstream file(filename, std::ios::binary);
    if (!file.is_open())
        throw std::runtime_error("Cannot open file: " + filename);

    int magic_number = 0, num_labels = 0;
    file.read((char*)&magic_number, 4);
    file.read((char*)&num_labels, 4);

    magic_number = reverse_int(magic_number);
    num_labels = reverse_int(num_labels);

    if (magic_number != 2049)
        throw std::runtime_error("Invalid MNIST label file!");

    std::vector<unsigned char> labels(num_labels);
    file.read((char*)labels.data(), num_labels);

    return labels;
}

void get_network_derivatives(std::vector<unsigned char> image, unsigned char label, std::vector<std::vector<float>>& w, std::vector<std::vector<float>>& b)
{
    NeuralNetwork::evaluate_input(image);

    std::vector<float> targets = std::vector<float>(10);
    for (size_t i = 0; i < 10; i++)
    {
        if (i == label)
            targets[i] = 1.0f;
    }
    NeuralNetwork::calculate_derivatives(targets, w, b);
}

void train_network(std::vector<unsigned int> indices, std::vector<std::vector<unsigned char>> images, std::vector<unsigned char> labels, float learnRate)
{
    std::vector<std::vector<float>> w, b, weightDerivatives, biasDerivatives;
    int minibatchSize = indices.size();

    weightDerivatives = NeuralNetwork::weightShape;
    biasDerivatives = NeuralNetwork::biasShape;

    //Sum up derivatives over minibatch
    for (size_t i = 0; i < minibatchSize; i++)
    {
        get_network_derivatives(images[indices[i]], labels[indices[i]], w, b);

        for (size_t j = 0; j < weightDerivatives.size(); j++)
        {
            for (size_t k = 0; k < weightDerivatives[j].size(); k++)
            {
                weightDerivatives[j][k] += w[j][k];
            }
        }

        for (size_t j = 0; j < biasDerivatives.size(); j++)
        {
            for (size_t k = 0; k < biasDerivatives[j].size(); k++)
            {
                biasDerivatives[j][k] += b[j][k];
            }
        }
    }

    //Adjust weights and biases by average derivatives

    NeuralNetwork::update_parameters(weightDerivatives, biasDerivatives, learnRate, minibatchSize);
}

void transform_images(std::vector<std::vector<unsigned char>>& images, int imageSize, int xOffset, int yOffset)
{
    for (size_t i = 0; i < images.size(); i++)
    {
        std::vector<unsigned char> newImage = std::vector<unsigned char>(imageSize * imageSize);
        for (size_t j = 0; j < images[i].size(); j++)
        {
            int xPos = j % imageSize;
            int yPos = j / imageSize;

            int xSamplePos = xPos - xOffset;
            int ySamplePos = yPos - yOffset;

            if (xSamplePos < 0 || xSamplePos >= imageSize || ySamplePos < 0 || ySamplePos >= imageSize)
                newImage[j] = 0;
            else
                newImage[j] = images[i][ySamplePos * imageSize + xSamplePos];
        }
        images[i] = newImage;
    }
}

void flip_images(std::vector<std::vector<unsigned char>>& images, int imageSize)
{
    for (size_t i = 0; i < images.size(); i++)
    {
        std::vector<unsigned char> newImage = std::vector<unsigned char>(imageSize * imageSize);
        for (size_t j = 0; j < images[i].size(); j++)
        {
            int xPos = j % imageSize;
            int yPos = j / imageSize;

            newImage[j] = images[i][(imageSize - yPos - 1) * imageSize + xPos];
        }
        images[i] = newImage;
    }
}

void display_mnist_image(std::vector<unsigned char>& image)
{
    gridData = image;
    glDeleteTextures(1, &gridTexture);
    gridTexture = gen_grid_texture(gridSize);
}

float gridVertices[] = {
    1.0f,  1.0f,  
     1.0f, -1.0f, 
    -1.0f,  1.0f, 

     1.0f, -1.0f,  
    -1.0f, -1.0f,  
    -1.0f,  1.0f
};

unsigned int gridIndices[] = {
    0, 1, 2,
    3, 4, 5
};

int main()
{
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    //Set the color channel precision
    glfwWindowHint(GLFW_RED_BITS, 8);
    glfwWindowHint(GLFW_GREEN_BITS, 8);
    glfwWindowHint(GLFW_BLUE_BITS, 8);
    glfwWindowHint(GLFW_ALPHA_BITS, 8);

    GLFWwindow* window = glfwCreateWindow(screenWidth, screenHeight, "LearnOpenGL", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);

    if (!gladLoadGLLoader((GLADloadproc) glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    // --- Create render buffers ---

    //Create grid buffers
    unsigned int gridVAO, gridVBO, gridEBO;

    GLHelper::gen_render_buffers(&gridVAO, &gridVBO, &gridEBO, gridVertices, sizeof(gridVertices), gridIndices, sizeof(gridIndices));

    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    //Create character buffers
    std::string characterText;
    std::string lastCharacterText;
    std::vector<float> characterVertices;
    std::vector<unsigned int> characterIndices;

    GLHelper::parse_font_atlas("Unnamed.fnt", atlasWidth, atlasHeight, characters);
    unsigned int characterVAO, characterVBO, characterEBO;

    gen_character_buffers(characterText, characterVertices, characterIndices, &characterVAO, &characterVBO, &characterEBO);

    // --- Set Up shader programs ---

    //Grid Shaders
    unsigned int gridShaderProgram;
    gridShaderProgram = glCreateProgram();

    std::string gridVertexShaderCode = GLHelper::read_shader("GridVertex.shader");
    std::string gridFragmentShaderCode = GLHelper::read_shader("GridFragment.shader");

    const char* gridVertexShaderSource = gridVertexShaderCode.c_str();
    const char* gridFragmentShaderSource = gridFragmentShaderCode.c_str();

    GLHelper::gen_shader_program(gridVertexShaderSource, gridFragmentShaderSource, &gridShaderProgram);

    //Character Shaders
    unsigned int characterShaderProgram;
    characterShaderProgram = glCreateProgram();

    std::string characterVertexShaderCode = GLHelper::read_shader("CharacterVertex.shader");
    std::string characterFragmentShaderCode = GLHelper::read_shader("CharacterFragment.shader");

    const char* characterVertexShaderSource = characterVertexShaderCode.c_str();
    const char* characterFragmentShaderSource = characterFragmentShaderCode.c_str();

    GLHelper::gen_shader_program(characterVertexShaderSource, characterFragmentShaderSource, &characterShaderProgram);

    // --- Set Uniforms --- 

    //Grid Uniforms
    glUseProgram(gridShaderProgram);
    gridTexture = gen_grid_texture(gridSize);
    glUniform1i(glGetUniformLocation(gridShaderProgram, "gridTexture"), 0);
    glUniform2f(glGetUniformLocation(gridShaderProgram, "resolution"), screenWidth * screenSplit, screenHeight);

    //Character Uniforms
    glUseProgram(characterShaderProgram);
    int width, height, channels;
    unsigned int characterTexture = gen_character_texture("Unnamed.png", &width, &height, &channels);
    glUniform1i(glGetUniformLocation(characterShaderProgram, "characterTexture"), 1);
    glUniform3f(glGetUniformLocation(characterShaderProgram, "textColor"), 1.0f,0.0f,0.0f);

    // --- Set callbacks ---
    glfwSetCursorPosCallback(window, cursor_position_callback);
    glfwSetMouseButtonCallback(window, mouse_button_callback);

    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glViewport(0, 0, screenWidth, screenHeight);
    glClearColor(1.0f, 0.0f, 0.5f, 1.0f);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);

    // --- Setup ImGui ---
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    (void)io; // silence unused warning

    // Setup ImGui style
    ImGui::StyleColorsDark();

    // Setup Platform/Renderer bindings
    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init("#version 460");

    // --- Initialize network data ---
    
    int minibatchSize = 32;
    int trainingIterations = 10;
    float learnRate = 0.01f;

    // Parse image and label data
    unsigned int numImages;
    std::vector<std::vector<unsigned char>> networkImageData = read_mnist_images("train-images.idx3-ubyte", &numImages);
    flip_images(networkImageData, gridSize);

    std::vector<unsigned char> networkLabelData = read_mnist_labels("train-labels.idx1-ubyte");

    // Setup network
    NeuralNetwork::gen_network();
    NeuralNetwork::read_parameters("NetworkParameters.txt");

    // --- Rendering loop ---
    while (!glfwWindowShouldClose(window))
    {
        glfwPollEvents();

        float time = glfwGetTime();
        deltaTime = time - lastTime;
        lastTime = time;

        if (showUI)
        {
            // Start ImGui frame
            ImGui_ImplOpenGL3_NewFrame();
            ImGui_ImplGlfw_NewFrame();
            ImGui::NewFrame();

            // ImGui Window
            ImGui::Begin("Neural Network");
            ImGui::Text("Network settings");
            ImGui::SliderInt("Minibatch Size", &minibatchSize, 1, 1024);
            ImGui::SliderInt("Iterations", &trainingIterations, 1, 10000);
            ImGui::SliderFloat("Learn Rate", &learnRate, 0.00001f, 0.5f);

            if (ImGui::Button("Train"))
            {
                float trainingStartTime = glfwGetTime();
                float trainingTime = 0.0f;
                for (size_t i = 0; i < trainingIterations; i++)
                {
                    std::vector<unsigned int> minibatchImageIndices(minibatchSize);
                    for (size_t j = 0; j < minibatchSize; j++)
                    {
                        minibatchImageIndices[j] = (rand() * 2) % numImages;
                    }

                    train_network(minibatchImageIndices, networkImageData, networkLabelData, learnRate);

                    trainingTime = glfwGetTime() - trainingStartTime;
                    float remainingTime = trainingTime / (i+1) * (trainingIterations - (i+1));

                    // Print training percentage and estimated time left every 100 iterations and on last iteration
                    if ((i + 1) % 100 == 0 || i == trainingIterations - 1)
                        std::cout << "Training " << (i + 1) * 100.0f / trainingIterations << "% Complete. " << "Estimated " << remainingTime << " Seconds Remaining" << std::endl;
                }

                unsigned int numTestImages;
                std::vector<std::vector<unsigned char>> testImages = read_mnist_images("t10k-images.idx3-ubyte", &numTestImages);
                flip_images(testImages, gridSize);
                std::vector<unsigned char> testLabels = read_mnist_labels("t10k-labels.idx1-ubyte");
                std::cout << NeuralNetwork::get_accuracy(testImages, testLabels) * 100.0f << "% Accuracy" << std::endl;
            }
            if (ImGui::Button("Clear Grid"))
                clear_grid();
            if (ImGui::Button("Clear Network Parameters"))
                NeuralNetwork::gen_network();
            if (ImGui::Button("Save Network Configuration"))
                NeuralNetwork::write_parameters("NetworkParameters.txt");
            if (ImGui::Button("Display Mnist Inage"))
                display_mnist_image(networkImageData[(rand() * 2) % numImages]);

            ImGui::End();

            // --- Rendering ---
            ImGui::Render();
        }

        // --- Reseting Window ---
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // --- Drawing grid ---
        glViewport(0, 0, screenWidth * screenSplit, screenHeight);
        glUseProgram(gridShaderProgram);
        glUniform2f(glGetUniformLocation(gridShaderProgram, "resolution"), screenWidth * screenSplit, screenHeight);
        glUniform1f(glGetUniformLocation(gridShaderProgram, "padding"), 0.1f);

        // Update Clicked Grid Square
        if (mouseClicked && !io.WantCaptureMouse)
        {
            int lastGridSquare = clickedGridSquare;
            clickedGridSquare = get_grid_square(xPos, yPos, screenWidth * screenSplit, screenHeight, gridSize, 0.1f);

            if (square_in_grid(clickedGridSquare) && clickedGridSquare != lastGridSquare)
            {
                if (shiftPressed)
                    set_grid_squares(clickedGridSquare, 0, 2.5f);
                else
                    set_grid_squares(clickedGridSquare, 255, 2.5f);
                glDeleteTextures(1, &gridTexture);
                gridTexture = gen_grid_texture(gridSize);

                //NeuralNetwork::debug_layer_stats();
            }
        }
        glBindVertexArray(gridVAO);
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

        glViewport(screenWidth * screenSplit, 0, screenWidth * (1 - screenSplit), screenHeight);

        // --- Recreate the character buffers --- 
        characterText = std::to_string(NeuralNetwork::evaluate_input(gridData));
        if (characterText != lastCharacterText)
        {
            glDeleteVertexArrays(1, &characterVAO);
            glDeleteBuffers(1, &characterVBO);
            glDeleteBuffers(1, &characterEBO);
        
            gen_character_buffers(characterText, characterVertices, characterIndices, &characterVAO, &characterVBO, &characterEBO);
            lastCharacterText = characterText;
        }

        glUseProgram(characterShaderProgram);
        glBindVertexArray(characterVAO);
        glDrawElements(GL_TRIANGLES, characterText.length() * 6, GL_UNSIGNED_INT, 0);


        if (showUI)
            ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        process_input(window);

        glfwSwapBuffers(window);
    }
    // --- Cleanup ---
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glfwTerminate();
    return 0;
}